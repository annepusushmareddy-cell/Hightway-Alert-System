(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const vehicles = [
    { id: "truck", name: "Truck", lane: 25, top: 70, emoji: "🚚", speed: 90 },
    { id: "carA", name: "You", lane: 50, top: 52, emoji: "🚙", speed: 90 },
    { id: "carB", name: "Car B", lane: 75, top: 35, emoji: "🚗", speed: 90 },
    { id: "carC", name: "Car C", lane: 25, top: 18, emoji: "🚕", speed: 90 },
    { id: "carD", name: "Car D", lane: 75, top: 8, emoji: "🚘", speed: 90 },
    { id: "carE", name: "Car E", lane: 50, top: 86, emoji: "🚙", speed: 90 }
  ];
  const eventInfo = {
    brake: { title: "Sudden stop ahead", label: "HARD BRAKING", emoji: "🛑", severity: "DANGER", message: "Hard braking detected ahead. Slow down and keep a safe distance." },
    pothole: { title: "Road damage ahead", label: "POTHOLE", emoji: "🕳️", severity: "WARNING", message: "Road damage reported ahead. Reduce speed and avoid sudden steering." },
    accident: { title: "Accident ahead", label: "ACCIDENT AHEAD", emoji: "🚧", severity: "DANGER", message: "Accident reported ahead. Prepare to slow down and follow road signs." },
    pedestrian: { title: "Person on road", label: "PERSON ON ROAD", emoji: "🚶", severity: "DANGER", message: "Person detected on the road. Slow down and be prepared to stop." },
    drunk: { title: "Alcohol warning nearby", label: "ALCOHOL WARNING", emoji: "⚠️", severity: "WARNING", message: "Alcohol sensor demo alert: a potentially unsafe driver is nearby. Keep distance and report danger safely." }
  };

  let eventCount = 0;
  let crashCount = 0;
  let activeEvent = null;
  let soundContext = null;
  let lastVoiceAt = 0;

  function addLog(title, detail) {
    const log = $("eventLog");
    const placeholder = log.querySelector(".log-placeholder");
    if (placeholder) placeholder.remove();
    const li = document.createElement("li");
    const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    const strong = document.createElement("strong");
    strong.textContent = title;
    const detailText = document.createElement("div");
    detailText.textContent = detail;
    const stamp = document.createElement("time");
    stamp.textContent = time;
    li.append(strong, detailText, stamp);
    log.prepend(li);
    eventCount++;
    $("logCount").textContent = `${eventCount} event${eventCount === 1 ? "" : "s"}`;
  }

  function beep() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      soundContext = soundContext || new AudioCtx();
      if (soundContext.state === "suspended") soundContext.resume();
      const osc = soundContext.createOscillator();
      const gain = soundContext.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(880, soundContext.currentTime);
      osc.frequency.exponentialRampToValueAtTime(540, soundContext.currentTime + 0.22);
      gain.gain.setValueAtTime(0.0001, soundContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.16, soundContext.currentTime + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, soundContext.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(soundContext.destination);
      osc.start();
      osc.stop(soundContext.currentTime + 0.31);
    } catch (_) { /* Audio may be blocked by browser settings. */ }
  }

  function speak(message) {
    if (!$("voiceToggle").checked || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.rate = 0.95;
    utterance.pitch = 1;
    window.speechSynthesis.speak(utterance);
  }

  function showRecipients(eventKey, info) {
    const list = $("recipientList");
    const state = $("alertState");
    const recipients = eventKey === "drunk"
      ? ["Truck", "You", "Car B", "Car C", "Car D", "Car E"]
      : ["You", "Car B", "Car C", "Car D", "Car E"];
    const broadcastOn = $("alertsToggle").checked;
    const filtered = eventKey === "drunk" ? recipients : recipients;
    $("receivedCount").textContent = `${broadcastOn ? filtered.length : 0} received`;
    state.classList.add("hidden");
    list.classList.remove("hidden");
    list.replaceChildren();
    filtered.forEach((name, index) => {
      const row = document.createElement("div");
      row.className = "recipient";
      const left = document.createElement("span");
      left.textContent = name;
      const right = document.createElement("span");
      if (broadcastOn) {
        right.className = "received";
        right.textContent = "● ALERT RECEIVED";
      } else {
        right.className = "not-received";
        right.textContent = "○ NOT DELIVERED";
      }
      row.append(left, right);
      list.append(row);
    });
    if (!broadcastOn) $("receivedCount").textContent = "0 received";
  }

  function triggerEvent(key) {
    const info = eventInfo[key];
    if (!info) return;
    activeEvent = key;
    const marker = $("hazardMarker");
    marker.classList.remove("hidden");
    $("hazardEmoji").textContent = info.emoji;
    $("hazardLabel").textContent = info.label;
    marker.style.borderColor = info.severity === "DANGER" ? "#ff6577" : "#ffc46b";
    marker.style.background = info.severity === "DANGER" ? "#461e2bdc" : "#493722e8";
    $("roadMessage").textContent = `${info.title} · ${$("alertsToggle").checked ? "broadcast sent" : "broadcast disabled"}`;
    $("roadOverlay").classList.toggle("hidden", $("alertsToggle").checked);
    $("overlayText").textContent = $("alertsToggle").checked ? "ALERT BROADCAST" : "ALERTS OFF — LATE REACTION";
    showRecipients(key, info);
    if ($("alertsToggle").checked) {
      beep();
      speak(info.message);
      addLog(`${info.severity}: ${info.title}`, "Broadcast simulation: recipients behind the hazard were notified in the demo.");
      const carA = $("carA");
      if (key === "pothole" || key === "accident" || key === "pedestrian") {
        carA.style.left = "50%";
        carA.style.top = "57%";
      } else if (key === "brake") {
        carA.style.top = "59%";
      } else {
        addLog("Nearby vehicle warning", "Configured demonstration radius: 300 m (simulated).");
      }
      $("crashNote").textContent = "Alert active: early warning simulated";
    } else {
      crashCount += key === "brake" || key === "accident" ? 3 : 0;
      $("crashCount").textContent = crashCount;
      $("crashNote").textContent = crashCount ? "Illustrative no-alert scenario" : "No crash event simulated";
      addLog(`ALERTS OFF: ${info.title}`, key === "brake" || key === "accident"
        ? "Illustrative scenario: 3 potential collisions shown for comparison, not measured real-world data."
        : "No broadcast was delivered. Drivers may learn about the hazard later.");
      $("roadOverlay").classList.remove("hidden");
      $("roadOverlay").style.background = "#341521a8";
      $("overlayText").textContent = "ALERTS OFF";
      beep();
    }
    $("systemStatus").textContent = $("alertsToggle").checked ? "ALERT BROADCAST" : "BROADCAST DISABLED";
  }

  function reset() {
    activeEvent = null;
    crashCount = 0;
    $("crashCount").textContent = "0";
    $("crashNote").textContent = "No crash event simulated";
    $("roadMessage").textContent = "Ready for a hazard event";
    $("systemStatus").textContent = "SYSTEM READY";
    $("hazardMarker").classList.add("hidden");
    $("roadOverlay").classList.add("hidden");
    $("alertState").classList.remove("hidden");
    $("recipientList").classList.add("hidden");
    $("receivedCount").textContent = "0 received";
    $("alertsToggle").checked = true;
    vehicles.forEach(v => {
      const el = $(v.id);
      el.style.left = `${v.lane}%`;
      el.style.top = `${v.top}%`;
    });
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    addLog("Simulation reset", "Vehicle positions and counters restored.");
  }

  document.querySelectorAll("[data-event]").forEach(button => {
    button.addEventListener("click", () => triggerEvent(button.dataset.event));
  });
  $("alertsToggle").addEventListener("change", () => {
    const on = $("alertsToggle").checked;
    $("systemStatus").textContent = on ? "SYSTEM READY" : "BROADCAST DISABLED";
    if (activeEvent) {
      const info = eventInfo[activeEvent];
      $("roadMessage").textContent = `${info.title} · ${on ? "broadcast sent" : "broadcast disabled"}`;
      $("roadOverlay").classList.toggle("hidden", on);
      $("overlayText").textContent = on ? "ALERT BROADCAST" : "ALERTS OFF — LATE REACTION";
      showRecipients(activeEvent, info);
      addLog(on ? "Broadcast enabled" : "Broadcast disabled", `${info.title}: recipient delivery view updated.`);
    }
  });
  $("resetBtn").addEventListener("click", reset);
  $("clearBtn").addEventListener("click", () => {
    $("eventLog").replaceChildren();
    eventCount = 0;
    $("logCount").textContent = "0 events";
    const li = document.createElement("li");
    li.className = "log-placeholder";
    li.textContent = "Events will appear here when you trigger a hazard.";
    $("eventLog").append(li);
  });

  // Gentle vehicle movement makes the road view feel active; this is visual-only.
  let tick = 0;
  window.setInterval(() => {
    tick++;
    if (activeEvent) return;
    vehicles.forEach((v, i) => {
      const el = $(v.id);
      const base = v.top;
      const drift = Math.sin((tick / 12) + i) * 1.8;
      el.style.top = `${Math.max(6, Math.min(89, base + drift))}%`;
    });
  }, 900);
})();