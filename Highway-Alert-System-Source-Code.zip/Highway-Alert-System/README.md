# Highway Alert System — V2V Simulation

A browser-based demonstration of a conceptual Vehicle-to-Vehicle (V2V) highway hazard alert system.

## Features

- Animated highway with six demo vehicles
- Simulated sudden braking, pothole, accident, person-on-road, and alcohol-sensor warning events
- Broadcast alerts ON/OFF comparison
- Recipient status panel for vehicles in the demo
- Optional spoken warnings using the browser's speech synthesis
- Beep sound using the Web Audio API
- Event history and reset controls
- Responsive layout for desktop and mobile

## Run locally

1. Download or extract this folder.
2. Open `index.html` in a modern browser such as Chrome or Edge.
3. Click one of the hazard buttons to run a simulation.
4. Turn broadcast alerts OFF to compare the no-broadcast scenario.

No package installation or server is required.

## Important limitations

This is a software simulation only. It does not connect to real vehicles, actual V2V/5G radio, physical sensors, GPS, or vehicle brakes. The displayed delivery time and broadcast range are illustrative configuration values, not measured performance. Do not use this demo for real driving or safety decisions.

## Technologies

HTML5, CSS3, JavaScript, Web Audio API, and Speech Synthesis API.
